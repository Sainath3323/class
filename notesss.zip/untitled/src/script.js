let isAdmin = false;

// Admin login button event listener
document.getElementById('adminLoginButton').addEventListener('click', function() {
    const password = document.getElementById('adminPassword').value;
    if (password === 'admin123') {
        isAdmin = true;
        alert('Admin mode activated');
        
        // Show the upload form for the admin and add delete buttons
        document.getElementById('uploadForm').style.display = 'block';
        document.getElementById('adminPassword').value = ''; // Clear the password field for security
        addDeleteButtons();
    } else {
        alert('Incorrect password');
    }
});

// Upload form submission event listener
document.getElementById('uploadForm').addEventListener('submit', function(e) {
    e.preventDefault();

    if (!isAdmin) {
        alert('Only admin can upload notes');
        return;
    }

    const subject = document.getElementById('subject').value.trim();
    const fileInput = document.getElementById('file');
    const file = fileInput.files[0];

    if (subject && file) {
        if (file.type === 'application/pdf') {
            const noteElement = document.createElement('div');
            noteElement.classList.add('note');

            // Create a view link for the PDF
            const viewLink = document.createElement('a');
            viewLink.href = URL.createObjectURL(file);
            viewLink.target = '_blank';
            viewLink.textContent = 'Open PDF';
            viewLink.style.display = 'block';
            viewLink.style.marginTop = '10px';

            noteElement.innerHTML = `<strong>Subject:</strong> ${subject}<br>`;
            noteElement.appendChild(viewLink);

            // Add delete button if admin is logged in
            if (isAdmin) {
                addDeleteButton(noteElement);
            }

            document.getElementById('notesContainer').appendChild(noteElement);

            // Clear input fields after upload
            document.getElementById('subject').value = '';
            fileInput.value = '';
        } else {
            alert('Please upload a valid PDF file');
        }
    } else {
        alert('Please fill in all fields');
    }
});

// Function to add a delete button to a note element
function addDeleteButton(noteElement) {
    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.style.marginTop = '10px';
    deleteButton.onclick = function() {
        noteElement.remove();
    };
    noteElement.appendChild(deleteButton);
}

// Function to add delete buttons to existing notes if admin is logged in
function addDeleteButtons() {
    const notes = document.querySelectorAll('.note');
    notes.forEach(note => {
        if (!note.querySelector('button')) { // Avoid adding duplicate delete buttons
            addDeleteButton(note);
        }
    });
}
